# Scripts et données du projet Fournil

Les scripts et CSV sont regroupés dans `assets/supports/scripts/` du ZIP. Conserver tous les fichiers dans le même dossier avant de les utiliser.

- [00-Creer-VMware-Workstation.ps1](../assets/supports/scripts/00-Creer-VMware-Workstation.ps1)
- [00-Deploiement-Complet.ps1](../assets/supports/scripts/00-Deploiement-Complet.ps1)
- [01-AD-Arborescence.ps1](../assets/supports/scripts/01-AD-Arborescence.ps1)
- [02-DFS-Deploiement.ps1](../assets/supports/scripts/02-DFS-Deploiement.ps1)
- [03-GPO-Home.ps1](../assets/supports/scripts/03-GPO-Home.ps1)
- [orga-fournil.csv](../assets/supports/scripts/orga-fournil.csv)
- [Set-NetworkLocation.ps1](../assets/supports/scripts/Set-NetworkLocation.ps1)
- [utilisateurs-fournil.csv](../assets/supports/scripts/utilisateurs-fournil.csv)
