# 08. Tiering : cloisonner l'administration

> **Objectif** : Comprendre pourquoi un compte administrateur ne doit jamais se connecter « n'importe où », découper le SI en niveaux (tiers), et mettre en place les barrières de base : comptes séparés, GPO d'interdiction de connexion, groupe Protected Users et Windows LAPS.

> [!INFO] Fil rouge — Fournil
> Domaine : `ad.fournil.lab` — NetBIOS : `FOURNIL` — DC : `DC01` (`192.168.3.10`) — poste : `PC-PROD-01`

**Outils abordés :** `dsa.msc`, `gpmc.msc`, module PowerShell `ActiveDirectory`, module `LAPS`
**Concepts clés :** vol d'identifiants, Tier 0 / 1 / 2, règle « jamais vers le bas », comptes d'administration par niveau, droits « Interdire l'ouverture de session », groupes restreints, Protected Users, Windows LAPS

---

## 1. Le problème : les identifiants restent sur la machine

Quand un compte ouvre une session **interactive** sur un ordinateur (console, Bureau à distance, `runas`, tâche planifiée, service), Windows garde de quoi le réauthentifier en mémoire (processus **LSASS**) : hash NTLM, tickets Kerberos.

Un attaquant qui prend le contrôle de cette machine peut récupérer ces secrets et **se faire passer pour le compte** (attaques *pass-the-hash*, *pass-the-ticket*), sans jamais connaître le mot de passe.

![Schema-Tiering-Vol-Identifiants](../assets/supports/241e562af5e32fe0e2fe.svg)

> [!WARNING] Ce n'est pas un scénario théorique
> C'est le chemin d'attaque le plus courant dans les rançongiciels : on ne « casse » pas le DC, on attend qu'un administrateur vienne se connecter sur une machine déjà compromise.

Le **tiering** répond à une seule question : *sur quelles machines chaque compte d'administration a-t-il le droit de se connecter ?*

- [Sécuriser l'accès privilégié — Microsoft Learn](https://learn.microsoft.com/fr-fr/security/privileged-access-workstations/overview)

---

## 2. Le modèle en trois niveaux

On classe chaque machine et chaque compte selon **ce qu'il permet de contrôler** :

| Niveau | Contient | Pourquoi |
|---|---|---|
| **Tier 0** | DC, l'annuaire AD lui-même, comptes *Admins du domaine* / *Administrateurs de l'entreprise*, PKI (AD CS), Entra Connect, **hyperviseurs et sauvegardes qui hébergent ou copient les DC** | Qui contrôle un de ces éléments contrôle **tout le domaine** |
| **Tier 1** | Serveurs membres : fichiers, impression, bases de données, applications | Contrôle des **données et services** de l'entreprise |
| **Tier 2** | Postes de travail, portables, imprimantes, comptes du support | Contrôle des **utilisateurs** |

![Schema-Tiering-Niveaux](../assets/supports/435d37e243bfebd244ba.svg)

### La règle d'or

> **Un compte d'un niveau ne se connecte jamais sur une machine d'un niveau inférieur.**

- un compte **Tier 0** ne se connecte **que** sur des machines Tier 0 (DC, poste d'administration dédié) ;
- un compte **Tier 1** ne se connecte ni sur un poste utilisateur, ni sur un DC ;
- un compte **Tier 2** n'a aucun droit sur les serveurs ni sur les DC.

Moyen mnémotechnique : **« on ne descend jamais avec ses clés »**. Un compte puissant qui descend sur une machine moins protégée y laisse ses clés.

> [!NOTE] Et le modèle « Enterprise Access » ?
> Microsoft présente aujourd'hui le **modèle d'accès d'entreprise** (plan de contrôle, plan de gestion, plan de données/charges de travail, accès utilisateur), qui étend le tiering au cloud. Pour un SI on-premise, le découpage Tier 0 / 1 / 2 reste la base, et c'est celui qu'utilise l'**ANSSI** dans ses recommandations AD.
>
> - [Modèle d'accès d'entreprise — Microsoft Learn](https://learn.microsoft.com/fr-fr/security/privileged-access-workstations/privileged-access-access-model)
> - [Recommandations de sécurité relatives à Active Directory — ANSSI](https://cyber.gouv.fr/publications/recommandations-de-securite-relatives-active-directory)

---

## 3. Un compte par niveau et par administrateur

Le chapitre 06 posait la première règle : un compte d'administration séparé du compte quotidien. Le tiering la pousse plus loin : **un compte par niveau**.

| Personne | Compte quotidien | Tier 2 | Tier 1 | Tier 0 |
|---|---|---|---|---|
| Julie Renard (support) | `jrenard` | `adm2.jrenard` | — | — |
| Admin système Fournil | `sysinfo` | `adm2.sysinfo` | `adm1.sysinfo` | `adm0.sysinfo` |

- `jrenard` lit ses mails et navigue : **aucun droit d'administration** ;
- `adm2.jrenard` est administrateur local des **postes**, et de rien d'autre ;
- seul `adm0.sysinfo` est membre (indirect) de **Admins du domaine**.

> [!TIP] Convention de nommage
> Le préfixe `adm0.` / `adm1.` / `adm2.` permet de savoir d'un coup d'œil, dans un journal ou dans `dsa.msc`, à quel niveau appartient un compte. Peu importe la convention choisie, l'important est qu'elle soit **appliquée partout**.

---

## 4. Ranger l'annuaire par niveau

### Une OU Administration à côté de Fournil

Les comptes, groupes et machines d'administration vont dans une OU dédiée, `Administration`, placée **directement sous le domaine**, au même niveau que l'OU racine `Fournil`. Elle n'est **pas** rangée sous `Fournil`.

```
ad.fournil.lab
├── OU=Administration           ← hors de Fournil : ni ses délégations, ni ses GPO
│   ├── OU=Tier0
│   │   ├── OU=Comptes          ← adm0.*
│   │   ├── OU=Groupes          ← GG_Tier0_Admins
│   │   └── OU=Services         ← comptes de service Tier 0 (svc_backup)
│   ├── OU=Tier1
│   │   ├── OU=Comptes          ← adm1.*
│   │   ├── OU=Groupes          ← GG_Tier1_Admins
│   │   ├── OU=Serveurs         ← serveurs membres (SRV-FIC01…)
│   │   └── OU=Services         ← comptes de service des applications
│   └── OU=Tier2
│       ├── OU=Comptes          ← adm2.*
│       └── OU=Groupes          ← GG_Tier2_Admins
├── OU=Fournil                  ← objets métier (chapitres 02 à 07)
│   ├── OU=Utilisateurs
│   ├── OU=Groupes
│   └── OU=Ordinateurs
│       └── OU=Postes           ← machines Tier 2
└── OU=Domain Controllers       ← DC : Tier 0
```

Pourquoi pas sous `OU=Fournil` ? Parce que **tout ce qui est posé sur une OU est hérité par ses sous-OUs** :
- **délégations** : un droit « réinitialiser les mots de passe » donné sur `OU=Fournil` permettrait de réinitialiser `adm0.sysinfo`, et donc de devenir Tier 0 ;
- **GPO** : les GPO des utilisateurs et des postes s'appliqueraient aussi aux comptes et aux serveurs d'administration.

En séparant les deux branches dès la racine, l'héritage ne peut jamais faire passer un droit métier vers l'administration.

> [!NOTE] Les serveurs quittent `OU=Fournil`
> Au chapitre 02, on avait prévu `OU=Serveurs` sous `Fournil/Ordinateurs`. Avec le tiering, les serveurs membres sont des machines Tier 1 : ils passent dans `Administration/Tier1/Serveurs`. De même, `svc_backup` (chapitre 06) sauvegarde les DC : c'est un compte Tier 0, il passe dans `Administration/Tier0/Services`.

```powershell
$domaine = "DC=ad,DC=fournil,DC=lab"
$admin   = "OU=Administration,$domaine"

New-ADOrganizationalUnit -Name "Administration" -Path $domaine
foreach ($t in 0,1,2) {
    New-ADOrganizationalUnit -Name "Tier$t" -Path $admin
    foreach ($sous in "Comptes","Groupes") {
        New-ADOrganizationalUnit -Name $sous -Path "OU=Tier$t,$admin"
    }
    New-ADGroup -Name "GG_Tier${t}_Admins" -GroupScope Global -GroupCategory Security `
                -Path "OU=Groupes,OU=Tier$t,$admin"
}
New-ADOrganizationalUnit -Name "Services" -Path "OU=Tier0,$admin"
New-ADOrganizationalUnit -Name "Serveurs" -Path "OU=Tier1,$admin"
New-ADOrganizationalUnit -Name "Services" -Path "OU=Tier1,$admin"

# Seul le groupe Tier 0 donne les droits d'administration du domaine
Add-ADGroupMember -Identity "Admins du domaine" -Members "GG_Tier0_Admins"
```

> [!WARNING] Délégation sur l'OU Administration
> Qui peut modifier un objet de `OU=Tier0` (réinitialiser `adm0.sysinfo`, ajouter un membre à `GG_Tier0_Admins`) **devient** Tier 0. La délégation du support (chapitre 02) porte sur `OU=Utilisateurs,OU=Fournil` : comme `Administration` n'est pas sous `Fournil`, elle ne peut **pas** s'y étendre par héritage. On ne pose jamais de délégation à la racine du domaine.

---

## 5. Faire respecter la règle avec des GPO

Créer des comptes séparés ne suffit pas : rien n'empêche encore `adm0.sysinfo` de se connecter sur un poste. On le **bloque** avec les **droits utilisateur**.

### Les droits « Interdire l'ouverture de session »

`Configuration ordinateur → Stratégies → Paramètres Windows → Paramètres de sécurité → Stratégies locales → Attribution des droits utilisateur`

| Paramètre | Bloque |
|---|---|
| **Interdire l'ouverture d'une session locale** | console, `runas` |
| **Interdire l'ouverture de session par les services Bureau à distance** | RDP |
| **Interdire l'ouverture de session en tant que tâche** | tâches planifiées |
| **Interdire l'ouverture de session en tant que service** | services Windows |

Les connexions **réseau** (accès à un partage, console MMC à distance) ne sont pas bloquées : elles ne laissent pas d'identifiants réutilisables sur la machine cible.

### Quelle GPO, sur quelle OU ?

| GPO | Liée à | Interdit la connexion de | Donne l'admin local à |
|---|---|---|---|
| `GPO_Tier2_Postes` | `OU=Postes,OU=Ordinateurs,OU=Fournil` | `GG_Tier0_Admins`, `GG_Tier1_Admins`, `Admins du domaine` | `GG_Tier2_Admins` |
| `GPO_Tier1_Serveurs` | `OU=Serveurs,OU=Tier1,OU=Administration` | `GG_Tier0_Admins`, `GG_Tier2_Admins`, `Admins du domaine` | `GG_Tier1_Admins` |

L'administration locale se donne avec les **Groupes restreints** :
`Paramètres de sécurité → Groupes restreints → Ajouter un groupe → GG_Tier2_Admins` → section **« Ce groupe est membre de »** → `Administrateurs`.

> [!WARNING] Utiliser « Ce groupe est membre de », jamais « Membres de ce groupe »
> Dans un groupe restreint, la section **Membres de ce groupe** **remplace** la liste complète des membres du groupe ciblé. Restreindre ainsi `Administrateurs` effacerait tous les autres administrateurs locaux du poste. La section **Ce groupe est membre de** se contente d'**ajouter** `GG_Tier2_Admins` dans `Administrateurs`.

> [!WARNING] Ne jamais lier ces GPO à la racine du domaine ni à `Domain Controllers`
> Une interdiction appliquée par erreur aux DC peut empêcher **tous** les administrateurs de s'y connecter. On teste d'abord avec un seul compte, sur un seul poste, et on garde le compte `Administrateur` intégré hors de ces groupes (compte de secours, mot de passe sous enveloppe).

### Le résultat sur le poste

Un compte Tier 0 qui tente d'ouvrir une session sur `PC-PROD-01` est refusé, même avec le bon mot de passe :

![ad-tp08-refus-adm0-poste](../assets/supports/12c7f92c1b03c78f90c6.png)
*« La méthode de connexion que vous tentez d’utiliser n’est pas autorisée » : c'est le droit « Interdire l'ouverture d'une session locale ».*

Le compte Tier 2, lui, ouvre sa session et se retrouve administrateur du poste par le groupe `GG_Tier2_Admins` :

![ad-tp08-adm2-admin-poste](../assets/supports/e55eea19076b233a64ed.png)

> [!NOTE] L'interdiction vise aussi PowerShell Direct
> Une fois la GPO appliquée, même `Invoke-Command -VMName` (PowerShell Direct depuis l'hôte Hyper-V) est refusé au compte Administrateur du domaine sur le poste : *« Les informations d'identification ne sont pas valides »*. Pour administrer les postes, on utilise un compte Tier 2.

---

## 6. Le groupe Protected Users

`Protected Users` est un groupe de sécurité intégré (niveau fonctionnel 2012 R2 et plus). Ses membres bénéficient de protections **non configurables** :

| Protection | Effet |
|---|---|
| Pas de **NTLM** | Authentification Kerberos uniquement : le hash NTLM n'est plus utilisable |
| Pas de chiffrement faible | Ni DES, ni RC4 dans Kerberos |
| Pas d'**identifiants en cache** | Pas de connexion hors ligne avec ce compte |
| Pas de délégation Kerberos | Le compte ne peut pas être délégué à un autre service |
| TGT de **4 heures** | Les tickets volés expirent vite |

```powershell
Add-ADGroupMember -Identity "Protected Users" -Members "adm0.sysinfo"
Get-ADGroupMember -Identity "Protected Users"
```

> [!WARNING] À réserver aux comptes humains d'administration
> - **Jamais** de compte de service ni de compte ordinateur dans `Protected Users` : ils ont souvent besoin de NTLM ou de délégation.
> - Une connexion **par adresse IP** (`\\192.168.3.10\partage`) passe en NTLM : elle échoue pour un membre de `Protected Users`. Il faut utiliser le **nom** (`\\DC01\partage`).
> - Garder au moins un compte de secours **hors** du groupe.

![ad-tp08-protected-users-ntlm](../assets/supports/92485545f07ab6cc47a5.png)
*`net use` avec `adm0.sysinfo` (membre de Protected Users) : par le **nom** `\\DC01`, ça passe (Kerberos). Par l'**adresse IP**, on obtient « L’erreur système 1327 s’est produite — Des restrictions de compte d’utilisateur empêchent cet utilisateur de se connecter » (NTLM refusé).*

- [Groupe Protected Users — Microsoft Learn](https://learn.microsoft.com/fr-fr/windows-server/security/credentials-protection-and-management/protected-users-security-group)

---

## 7. Windows LAPS : un mot de passe local différent par machine

Si tous les postes ont le **même** mot de passe pour le compte `Administrateur` local, compromettre un poste donne accès à **tous** les autres : c'est un mouvement latéral gratuit dans le Tier 2.

**Windows LAPS** (*Local Administrator Password Solution*) est intégré à Windows depuis avril 2023 (Windows 10/11, Windows Server 2019 et plus), sans rien installer. Chaque machine :
- génère un mot de passe aléatoire pour son compte administrateur local ;
- le change régulièrement ;
- le stocke **dans son propre objet ordinateur** AD, lisible uniquement par les groupes autorisés.

### Mise en place

```powershell
# 1. Étendre le schéma AD (une seule fois par forêt, en Admins du schéma)
Update-LapsADSchema

# 2. Autoriser les ordinateurs de l'OU à écrire leur propre mot de passe
Set-LapsADComputerSelfPermission -Identity "OU=Postes,OU=Ordinateurs,OU=Fournil,DC=ad,DC=fournil,DC=lab"

# 3. Autoriser le support Tier 2 à lire les mots de passe des postes
Set-LapsADReadPasswordPermission -Identity "OU=Postes,OU=Ordinateurs,OU=Fournil,DC=ad,DC=fournil,DC=lab" `
                                 -AllowedPrincipals "FOURNIL\GG_Tier2_Admins"
```

4. GPO liée à `OU=Postes` : `Configuration ordinateur → Stratégies → Modèles d'administration → Système → LAPS`

| Paramètre | Valeur |
|---|---|
| **Configurer le répertoire de sauvegarde des mots de passe** | Activé → *Active Directory* |
| **Paramètres du mot de passe** | Activé → complexité maximale, 16 caractères, 30 jours |
| **Configurer les déchiffreurs de mots de passe autorisés** | Activé → `FOURNIL\GG_Tier2_Admins` |

> [!WARNING] Le mot de passe est chiffré : le droit de lecture ne suffit pas
> Avec un domaine en niveau fonctionnel **2016 ou plus**, Windows LAPS **chiffre** le mot de passe dans AD. Seul le **déchiffreur autorisé** peut le lire, et c'est par défaut **Admins du domaine** :
> - avec seulement `Set-LapsADReadPasswordPermission`, `adm2.jrenard` obtient `DecryptionStatus : Unauthorized` et un mot de passe vide ;
> - avec le paramètre **Configurer les déchiffreurs de mots de passe autorisés** → `GG_Tier2_Admins`, il obtient `DecryptionStatus : Success`.
>
> Un seul déchiffreur par mot de passe : une fois `GG_Tier2_Admins` désigné, ce sont **les Admins du domaine** qui ne peuvent plus le déchiffrer. C'est cohérent avec le tiering : le mot de passe d'un poste appartient au Tier 2.

### Utilisation

```powershell
# Sur le poste : forcer le traitement sans attendre
Invoke-LapsPolicyProcessing

# Depuis le DC ou un poste d'administration : lire le mot de passe
Get-LapsADPassword -Identity "PC-PROD-01" -AsPlainText

# Forcer un nouveau mot de passe (après une intervention, par exemple)
Reset-LapsPassword            # à lancer sur le poste concerné
```

![ad-tp08-laps-adm2](../assets/supports/5bcb9f101e23122f8817.png)
*Lecture du mot de passe par `adm2.jrenard` : `Source : EncryptedPassword`, `DecryptionStatus : Success`, `AuthorizedDecryptor : FOURNIL\GG_Tier2_Admins`. La date d'expiration correspond aux 30 jours de la GPO.*

Sur le poste, le journal **Microsoft → Windows → LAPS → Operational** trace chaque rotation : **10018** (*LAPS successfully updated Active Directory with the new password*), puis **10020** (*… updated the local admin account with the new password*).

Dans `dsa.msc`, les propriétés d'un ordinateur géré affichent un onglet **LAPS** (mot de passe et date d'expiration).

- [Windows LAPS — Microsoft Learn](https://learn.microsoft.com/fr-fr/windows-server/identity/laps/laps-overview)

---

## 8. Pour aller plus loin (hors périmètre TSSR)

Ces mesures complètent le tiering dans les grandes organisations. Il suffit de savoir qu'elles existent :

| Mesure | Principe |
|---|---|
| **PAW** (*Privileged Access Workstation*) | Un poste dédié à l'administration d'un niveau, sans mail ni navigation. Il se range dans une sous-OU `PAW` du niveau concerné (`OU=PAW,OU=Tier0,OU=Administration`) |
| **Stratégies et silos d'authentification** | Restreindre côté DC (et non plus côté machine) où un compte peut s'authentifier |
| **Comptes de service gérés (gMSA)** | Mot de passe de compte de service géré automatiquement par AD |
| **Audit de l'annuaire** | Outils d'audit comme **PingCastle** ou **ORADAD** (ANSSI) pour mesurer l'exposition du Tier 0 |

---

> [!NOTE] À retenir
>
> - Se connecter **laisse des identifiants** sur la machine : un compte puissant ne va jamais sur une machine moins protégée.
> - **Tier 0** = ce qui contrôle le domaine (DC, AD, hyperviseurs et sauvegardes des DC). **Tier 1** = serveurs. **Tier 2** = postes.
> - **Un compte par niveau** : `adm0.`, `adm1.`, `adm2.`, et un compte quotidien sans droits.
> - L'OU **`Administration`** se place **à côté** de l'OU racine `Fournil`, jamais dessous : les délégations et GPO métier ne doivent pas l'atteindre par héritage.
> - Les **GPO d'interdiction d'ouverture de session** font respecter la règle, les **groupes restreints** (« Ce groupe est membre de ») donnent l'admin local au bon niveau.
> - **Protected Users** protège les comptes d'administration humains (pas les comptes de service).
> - **Windows LAPS** donne un mot de passe administrateur local unique à chaque machine.

---

## Résumé commandes

| Action | GUI | PowerShell |
|--------|-----|-----------|
| Créer l'arborescence d'administration | `dsa.msc` | `New-ADOrganizationalUnit`, `New-ADGroup` |
| Interdire la connexion d'un groupe | GPO → Attribution des droits utilisateur | — |
| Donner l'admin local à un groupe | GPO → Groupes restreints | — |
| Protéger un compte admin | `dsa.msc` → Protected Users | `Add-ADGroupMember "Protected Users"` |
| Préparer AD pour LAPS | — | `Update-LapsADSchema`, `Set-LapsADComputerSelfPermission` |
| Lire un mot de passe LAPS | `dsa.msc` → onglet LAPS | `Get-LapsADPassword -AsPlainText` |
| Comptes à privilèges historiques | — | `Get-ADUser -Filter 'adminCount -eq 1'` |
